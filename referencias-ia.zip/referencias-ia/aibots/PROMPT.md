# Imagen de AI BOTS para el portafolio (ChatGPT)

Capturas **reales** de doxi.ai-bots.us (panel con sesión iniciada + widget de chat conversando
de verdad con Doxi). Resolución alta (2x / 3x).

Adjunta estos 3 archivos en UN solo mensaje, en este orden, y pega el prompt de abajo:

1. `1-laptop-panel-playground.png` → panel de AI BOTS: configuración del agente + vista previa del chat
2. `2-widget-chat.png`             → el widget de Doxi en una conversación real ("Quiero agendar una cita")
3. `3-mascota-doxi-agenda.png`     → Doxi Agenda, la mascota oficial (PNG transparente)

Otras capturas en `capturas/` por si quieres cambiar la de la laptop (plantillas de chat, canales, resumen).

---

## Prompt

```
Create a premium product showcase image for a developer portfolio, presenting
"Doxi" by AI BOTS: AI agents that answer, book appointments and sell for
businesses on their website and WhatsApp.

ATTACHED IMAGES:
- Image 1 is a REAL screenshot of the AI BOTS dashboard. Use it as the exact
  screen content of a modern laptop. Do NOT redraw, redesign, translate or
  "improve" it: keep every word, icon, color and layout pixel-faithful, just
  mapped onto the laptop screen.
- Image 2 is a REAL screenshot of the Doxi chat widget in a live conversation.
  Show it as a floating chat window card (rounded corners, as it appears on a
  website), keeping its content pixel-faithful. Do not change any text.
- Image 3 is the official mascot (Doxi, the red-and-white robot holding a
  calendar). Keep it EXACTLY as given: same pose, face, colors and proportions.
  Do not redraw or restyle it.

COMPOSITION (landscape, 3:2):
- A modern thin-bezel laptop (no logo on it) shown perfectly FRONT-FACING, no
  tilt, no perspective, occupying about 65% of the width, slightly left of center.
- The chat widget card floating in front of the laptop's lower-right corner,
  overlapping it, about 35% of the image height, with a very soft shadow.
- The Doxi mascot standing at the right side, next to the chat card, about the
  same height as the chat card, as if presenting it.
- Everything well centered with generous margins on all sides; nothing cut off.

BACKGROUND: fully TRANSPARENT. Output as a PNG with a real alpha channel. No
background color, no floor, no glow, no gradient, no border. Only very subtle soft
shadows directly under the objects are allowed.

STYLE: clean, minimal, Apple-keynote-level product presentation, crisp and sharp,
high resolution.

DO NOT: add any new text, slogans, captions, fake UI, people, hands, other robots,
real brand logos (no Apple logo), store badges, watermarks, or a painted
checkerboard pattern.
```

---

## Si algo sale mal (prompts de edición)

Edita la imagen, no la regeneres:

- **Texto de la laptop o del chat deformado:**
  `Edit this image: keep everything exactly the same. Only replace the laptop screen with attached image 1 and the chat card content with attached image 2, exactly as they are, pixel-faithful, no changes to their text.` (adjunta otra vez 1 y 2)
- **La mascota cambió:**
  `Edit this image: keep everything exactly the same. Only replace the robot with the attached mascot, exactly as it is in the image (same pose, face and colors).` (adjunta otra vez la 3)
- **Fondo de cuadritos pintado (no es transparencia real):**
  `The checkerboard is painted in, I need a real transparent alpha channel. Keep everything else exactly the same.`

## Cuando la tengas

Guárdala en `public/fotos/proyectos/` (por ejemplo `aibots.png`) y avísame para conectarla.
