# Imagen de Consultorio Arrobo para el portafolio (ChatGPT)

Capturas **reales** del ERP en consultoriosarrobo.com (sesión de administrador), en alta
resolución (2x).

⚠️ **Privacidad:** es un sistema clínico real. Todos los nombres de pacientes y doctores,
cédulas, correos y teléfonos de estas capturas fueron **reemplazados por datos ficticios**
en el navegador antes de capturar (no se tocó nada en el sistema). No uses capturas sacadas
a mano del ERP sin anonimizarlas.

Adjunta estos 2 archivos en UN solo mensaje, en este orden, y pega el prompt de abajo:

1. `1-laptop-agenda-citas.png` → agenda del día por doctor (19 citas, vista Día)
2. `2-tablet-dashboard.png`    → dashboard: citas de hoy, módulos, alertas y próximas citas

Otras capturas en `capturas/` (catálogo de servicios, stock de inventario, facturas,
facturador, login) por si quieres cambiar alguna.

---

## Prompt

```
Create a premium product showcase image for a developer portfolio, presenting a
custom ERP for a dental clinic (appointments, clinical records, inventory and
electronic invoicing).

ATTACHED IMAGES:
- Image 1 is a REAL screenshot of the appointment calendar. Use it as the exact
  screen content of a modern laptop.
- Image 2 is a REAL screenshot of the main dashboard. Use it as the exact screen
  content of a tablet in LANDSCAPE orientation.
- Do NOT redraw, redesign, translate or "improve" the screenshots: keep every
  word, number, color and layout pixel-faithful, just mapped onto the screens.

COMPOSITION (landscape, 3:2):
- A modern thin-bezel laptop (no logo on it) shown perfectly FRONT-FACING, no
  tilt, no perspective, occupying about 70% of the width, slightly left of center.
- The tablet (thin dark bezel, landscape) standing in front of the laptop's
  lower-right corner, overlapping it, about 40% of the laptop's width, also
  perfectly front-facing.
- Everything well centered with generous margins on all sides; nothing cut off.

BACKGROUND: fully TRANSPARENT. Output as a PNG with a real alpha channel. No
background color, no desk, no floor, no glow, no gradient, no border. Only very
subtle soft shadows directly under the devices are allowed. The devices must be
fully opaque.

STYLE: clean, minimal, Apple-keynote-level product presentation, crisp and sharp,
high resolution.

DO NOT: add any new text, slogans, captions, fake UI, people, hands, teeth or
medical illustrations, real brand logos (no Apple logo), watermarks, or a painted
checkerboard pattern.
```

---

## Si algo sale mal (prompts de edición)

Edita la imagen, no la regeneres:

- **Texto de las pantallas deformado:**
  `Edit this image: keep everything exactly the same. Only replace the laptop screen with attached image 1 and the tablet screen with attached image 2, exactly as they are, pixel-faithful, no changes to their text.` (adjunta otra vez las 2)
- **Dispositivos inclinados:**
  `Edit this image: keep everything the same, but make both devices perfectly front-facing and flat, with no tilt or perspective.`
- **Fondo de cuadritos pintado (no es transparencia real):**
  `The checkerboard is painted in, I need a real transparent alpha channel. Keep everything else exactly the same.`

## Cuando la tengas

Guárdala en `public/fotos/proyectos/` (por ejemplo `arrobo.png`) y avísame para conectarla.
