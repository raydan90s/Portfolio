# Imagen de Alata para el portafolio (ChatGPT)

Capturas **reales** sacadas del emulador Android (app en modo oscuro, barra de estado limpia 9:41).

Adjunta estos 5 archivos en UN solo mensaje, en este orden, y pega el prompt de abajo:

1. `1-viaje-en-vivo.png`  → pasajero siguiendo el carro en el mapa
2. `2-inicio.png`         → "Hola, Jona", buscador y viajes disponibles
3. `3-publicar.png`       → conductor publicando su ruta
4. `4-logo-alata.png`     → logo oficial (versión para fondo oscuro)
5. `5-icono-app.png`      → ícono de la app

Más pantallas en `reales/` por si quieres cambiar alguna (mis viajes, detalle del viaje,
navegación del conductor, punto de recogida, perfil).

---

## Prompt

```
Create a premium product showcase image for a developer portfolio, presenting a
mobile app called aLata (university carpooling in Guayaquil, Ecuador).

ATTACHED IMAGES:
- Images 1, 2 and 3 are REAL screenshots of the app (dark mode). Use them as the
  exact screen content of three phones. Do NOT redraw, redesign, translate or
  "improve" them: keep every word, number, map line, color and layout
  pixel-faithful, just mapped onto the phone screens.
- Image 4 is the official logo (white letters, gold coin dot). Place it exactly as
  given, small, in the top-left corner. Do not redraw it or change its letters.
- Image 5 is the app icon: place it as a small rounded-square app icon right
  next to the logo.

COMPOSITION (landscape, 3:2):
- Background: deep charcoal #0F0F0E, almost flat, with one large, very soft warm
  gold glow (#F1B007 at low opacity) behind the center phone. Optionally, very
  faint thin map street lines in the background at 5% opacity. No other effects.
- Three modern smartphones with thin black bezels and rounded corners, all shown
  perfectly FRONT-FACING (no tilt, no perspective, no 3D rotation):
  screen 2 in the CENTER, largest and in front;
  screen 1 on the LEFT and screen 3 on the RIGHT, slightly smaller, slightly
  lower and partially behind the center phone.
- Very soft, short shadow under each phone. The phones occupy about 70% of the
  image width, centered slightly to the right; logo + icon top-left with
  generous empty space around them.
- Accent color only gold #F1B007 (already present in the logo and the screens).

STYLE: clean, minimal, Apple-keynote-level product presentation, crisp and sharp,
high resolution, lots of breathing room.

DO NOT: add any new text, slogans, captions, fake UI, people, hands, real brand
logos (no Apple logo), store badges, watermarks, glossy reflections or tilted
phones.
```

---

## Si algo sale mal (prompts de edición)

Edita la imagen, no la regeneres. Pega uno de estos:

- **Texto de las pantallas deformado:**
  `Edit this image: keep everything exactly the same. Only replace the content of the three phone screens with the attached screenshots (left = 1, center = 2, right = 3), exactly as they are, pixel-faithful, no changes to their text.` (adjunta otra vez las 3 pantallas)
- **Logo deformado:**
  `Edit this image: keep everything exactly the same. Only remove the logo and the app icon at the top-left, leaving plain background there.`
  → yo le pongo el logo real encima después.
- **Celulares inclinados:**
  `Edit this image: keep everything the same, but make all three phones perfectly front-facing and flat, with no tilt or perspective.`

## Cuando la tengas

Guárdala como `public/fotos/proyectos/alata.webp` (o `.png`) y avísame para conectarla.
