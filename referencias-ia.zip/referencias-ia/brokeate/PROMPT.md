# Imagen de Brokeate para el portafolio (ChatGPT)

Capturas **reales** de la app (el port web 1:1 de la app Expo, misma paleta y mismo código
de pantallas), corriendo contra **tu backend real** (FastAPI) con los **datos demo de
`seed.sql`** (Juan Pérez · perfil Moderado 12/15 · USD 20.000). Como la base de Supabase
ya no existe, se levantó una copia local de la base solo para capturar.

Tamaño 1290×2796 = resolución exacta de un iPhone Pro Max. Modo oscuro de la app.

Adjunta estos 3 archivos en UN solo mensaje, en este orden, y pega el prompt de abajo:

1. `1-simulador.png`  → simulador: monto, horizonte y la recomendación del motor (USD 11.134,25 · 11,5%)
2. `2-propuesta.png`  → la propuesta: dona 60/40, "En revisión" y la explicación del agente de IA
3. `3-mercados.png`   → mercados globales: Bitcoin con gráfico de 30 días y "Recomendación de Mercados (IA)"

Más pantallas en `capturas/oscuro` y `capturas/claro` (inicio, cómo se calculó, comparador,
noticias, WhatsApp, login) por si quieres cambiar alguna.

---

## Prompt

```
Create a premium product showcase image for a developer portfolio, presenting
Brokeate: an AI robo-advisor with a human advisor in the loop (it won 1st place
at a fintech AI hackathon).

ATTACHED IMAGES:
- Images 1, 2 and 3 are REAL screenshots of the app (dark mode). Use them as the
  exact screen content of three phones. Do NOT redraw, redesign, translate or
  "improve" them: keep every word, number, chart line, color and layout
  pixel-faithful, just mapped onto the phone screens.

COMPOSITION (landscape, 3:2):
- Three modern smartphones with thin black bezels and rounded corners, all shown
  perfectly FRONT-FACING (no tilt, no perspective, no 3D rotation):
  screen 2 in the CENTER, largest and in front;
  screen 1 on the LEFT and screen 3 on the RIGHT, slightly smaller, slightly
  lower and partially behind the center phone.
- The phones occupy about 75% of the image width, centered, with generous
  margins on all sides; nothing cut off.

BACKGROUND: fully TRANSPARENT. Output as a PNG with a real alpha channel. No
background color, no glow, no gradient, no floor, no border. Only very subtle
soft shadows directly under the phones are allowed. The phones must be fully
opaque.

STYLE: clean, minimal, Apple-keynote-level product presentation, crisp and sharp,
high resolution.

DO NOT: add any new text, slogans, captions, fake UI, people, hands, coins,
charts outside the screens, real brand logos (no Apple logo), store badges,
watermarks, or a painted checkerboard pattern.
```

---

## Si algo sale mal (prompts de edición)

Edita la imagen, no la regeneres:

- **Texto de las pantallas deformado:**
  `Edit this image: keep everything exactly the same. Only replace the content of the three phone screens with the attached screenshots (left = 1, center = 2, right = 3), exactly as they are, pixel-faithful, no changes to their text.` (adjunta otra vez las 3)
- **Celulares inclinados:**
  `Edit this image: keep everything the same, but make all three phones perfectly front-facing and flat, with no tilt or perspective.`
- **Fondo de cuadritos pintado (no es transparencia real):**
  `The checkerboard is painted in, I need a real transparent alpha channel. Keep everything else exactly the same.`

## Cuando la tengas

Guárdala en `public/fotos/proyectos/` (por ejemplo `brokeate.png`) y avísame para conectarla.
